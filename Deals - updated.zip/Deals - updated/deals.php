<?php


/*
Plugin Name:       Our Deals Plugin
Description:       this plugin help to manage your deals.
Version: 1.0
Requires at least: 5.2
Requires PHP:      7.2
Author:            Krishna Rajput
Author URI:        www.cybilltechnology.in
License:           GPL v2 or later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Update URI:        https://example.com/my-plugin/
Text Domain:       my-basics-plugin

*/

class DealsAndFundingPlugin
{
	function __construct()
	{
		add_action('admin_menu' , array($this, 'adminPlugin'));
		add_action('admin_init' , array($this, 'pluginSetting'));
		add_action('wp_enqueue_scripts', array($this, 'dealsStylesheet'));
		
        //register_activation_hook( __FILE__, 'jal_install_data' );

	}

	function pluginSetting()
	{
		add_settings_section('deals_first_field', null, null, 'deals-plugin-setting');
		add_settings_field('comapany_logo', 'Company Logo', array($this, 'companyLogo'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'comapany_logo', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('company_name', 'Company Name', array($this, 'companyName'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'company_name', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('company_sector', 'Company Name', array($this, 'companySector'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'company_sector', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('launch_year', 'Launch Year', array($this, 'lunchYear'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'launch_year', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('founders', 'Founders', array($this, 'company_Founders'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'founders', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('deal_stage', 'Deal Stage', array($this, 'dealStage'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'deal_stage', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('funding_amount', 'Funding Amount', array($this, 'fundingAmount'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'funding_amount', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('investors', 'Investors', array($this, 'Investors'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'investors', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('article_title', 'Article Title', array($this, 'articleTitle'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'article_title', array('sanitize_callback' => 'sanitize_logo'));
		add_settings_field('link_to_article', 'Article Link', array($this, 'articleLink'), 'deals-plugin-setting', 
			'deals_first_field');
		register_setting('dealplugin', 'link_to_article', array('sanitize_callback' => 'sanitize_logo'));

		


	}


	function companyLogo()
	{?>
	
	<input type="file" id="logo" name="logo" required="company logo">

	<?php
}

	function companyName()
	{?>
	
	<input type="text" name="company_name" id="company_name" required="company name">

	<?php
}

	function companySector()
	{?>
	
  <select name="sector" id="sector" required="select sector">
  	<option>Select Sectors</option>
  <option value="E-commerce" <?php selected(get_option('sector'), 'E-commerce') ?>>E-commerce</option>
  <option value="FinTech" <?php selected(get_option('sector'), 'FinTech') ?>>FinTech</option>
  <option value="Consumer Services" <?php selected(get_option('sector'), 'Consumer Services')?>>Consumer Services</option>
  <option value="HealthTech" <?php selected(get_option('sector'), 'HealthTech')?>>HealthTech</option>
  <option value="EdTech" <?php selected(get_option('sector'), 'EdTech') ?>>EdTech</option>
  <option value="AgriTech" <?php selected(get_option('sector'), 'AgriTech') ?>>AgriTech</option>
  <option value="Logistics" <?php selected(get_option('sector'), 'Logistics') ?>>Logistics</option>
</select>

	<?php
}
function lunchYear()
	{?>
	
  <input type="date" name="launch_year" id="launch_year" required="select date">

	<?php
}
function company_Founders()
	{?>
	
 <input type="text" name="founders" id="founders" required="founders">

	<?php
}
function dealStage()
	{?>
	
<select name="deal_stage" id="deal_stage">
  <option value="Seed" <?php selected(get_option('deal_stage'), 'Seed')?>>Seed</option>
  <option value="Pre-Series A" <?php selected(get_option('deal_stage'), 'Pre-Series A') ?>>Pre-Series A</option>
  <option value="Series A" <?php selected(get_option('deal_stage'), 'Series A') ?>>Series A</option>
  <option value="Pre-Series B" <?php selected(get_option('deal_stage'), 'Pre-Series A') ?>>Pre-Series B</option>
  <option value="Series B" <?php selected(get_option('deal_stage'), 'Series B') ?>>Series B</option>
  <option value="Series C" <?php selected(get_option('deal_stage'), 'Series C') ?>>Series C</option>
  <option value="Series D" <?php selected(get_option('deal_stage'), 'Series D') ?>>Series D</option>
  <option value="Series E" <?php selected(get_option('deal_stage'), 'Series E') ?>>Series E</option>
  <option value="Series F" <?php selected(get_option('deal_stage'), 'Series F') ?>>Series F</option>
  <option value="Late Stage" <?php selected(get_option('deal_stage'), 'Late Stage') ?>>Late Stage</option>
  <option value="Debt Financing" <?php selected(get_option('deal_stage'), 'Pre-Series A') ?>>Debt Financing</option>
  <option value="Acquisition" <?php selected(get_option('deal_stage'), 'Acquisition') ?>>Acquisition</option>
  <option value="IPO" <?php selected(get_option('deal_stage'), 'IPO') ?>>IPO</option>
</select>

	<?php
}
function fundingAmount()
	{?>
	
<input type="number" name="funding_amount" id="funding_amount" required="">

	<?php
}
function Investors()
	{?>
	
<input type="text" name="investors" id="investors" required="">

	<?php
}
function articleTitle()
	{?>
	
<input type="text" name="article_title" id="article_title" required="">

	<?php
}
function articleLink()
	{?>
	
<input type="text" name="link_to_article" id="link_to_article" required="">

	<?php
}


	function adminPlugin(){

	add_options_page('Deals Plugin', 'Deals-Funding', 'manage_options', 'deals-plugin-setting', array($this, 'pluginHTML'));
}
function pluginHTML()
{ ?>
<div class="wrap">
	<h1>Deals Plugin Setting</h1>
	
	<form action="options.php" method="POST">
		
		<?php
		settings_fields('dealplugin');
		do_settings_sections('deals-plugin-setting');
		submit_button();
		?>
		
	</form>

</div>

<?php
}
function dealsStylesheet()
{
wp_register_style( 'pure-awesome-style', plugins_url('css/cpure-awesome-styles.css', __FILE__), array() );
wp_enqueue_style( 'pure-awesome-style' );

}


}
 
 $dealsFunding =new DealsAndFundingPlugin();



// $logo="https://img.pngio.com/lays-wikipedia-lays-logo-png-1200_1134.png";
// $company_name="Lays";
// $table_name = $wpdb->prefix . 'deals';

// $wpdb->insert( 
// 	$table_name, 
// 	array( 
// 		'logo' => $logo, 
// 		'company_name' => $company_name, 
		
// 	) 
// );
//require_once('/wp-config.php');

 function table_create()
{
global $wpdb;
$table_name = $wpdb->prefix . "wpdeals"; 
$charset_collate = $wpdb->get_charset_collate();
 $sql = "CREATE TABLE IF NOT EXISTS $table_name (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  logo BLOB NOT NULL,
  company_name varchar(100) NOT NULL,
  sector varchar(100) NOT NULL,
  launch_year date NOT NULL,
  founders	varchar(100) NOT NULL,
  deal_stage varchar(100) NOT NULL,
  funding_amount bigint(20) NOT NULL,
  investors	varchar(100) NOT NULL,
  article_title	varchar(100) NOT NULL,
  link_to_article varchar(100) NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate";
require_once( ABSPATH .'wp-admin/includes/upgrade.php' );
dbDelta( $sql );
}
if ( isset( $_POST['submit'] ) ){

         global $wpdb;
         $tablename = $wpdb->prefix.'wpdeals';

        $wpdb->insert( $tablename, array(
            'logo' => $_POST['logo'], 
            'company_name' => $_POST['company_name'],
            'sector' => $_POST['sector'],
            'launch_year' => $_POST['launch_year'],
            'founders' => $_POST['founders'],
            'deal_stage' => $_POST['deal_stage'],
            'funding_amount' => $_POST['funding_amount'],
            'investors' => $_POST['investors'],
            'article_title' => $_POST['article_title'],
            'link_to_article' => $_POST['link_to_article'],
             ),
     
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s' )
        );
     
    }

   //  function deactivate_table()
   //  {
   //  	// uninstall mysql code
   // global $wpdb;
   // $wpdb->query("DROP table IF Exists wpdeals");
   
   // // step1: we get the id of post means page
   // // delete the post from table
   
   // $the_post_id = get_option("custom_plugin_page_id");
   // if(!empty($the_post_id)){
   //    wp_delete_post($the_post_id,true);
   
   //  }


register_activation_hook( __FILE__, 'table_create' );
//register_uninstall_hook(__FILE__,"deactivate_table");
//register_deactivation_hook(__FILE__,"deactivate_table");

//shortcode function start here


function allDealsPluginShortcode(){?>
<div class="wrap">
	<div class="container">
<div class="row">
<div class="col-md-3">

<div class="media">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVkCapwPtflcAddvNeLUVwUM4oax7vxWnFBw&usqp=CAU" class="align-self-start mr-3 rounded float-left" alt="..." width="164px" height="164px">
  <div class="media-body">
    <h5 class="mt-0" <?php selected(get_option('Comapny Name'), 'comapny_name')?>></h5>
    
  </div>
</div>


</div>
<div class="col-md-3">

<div class="media">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVkCapwPtflcAddvNeLUVwUM4oax7vxWnFBw&usqp=CAU" class="align-self-start mr-3" alt="...">
  <div class="media-body">
    <h5 class="mt-0">Comapny Name</h5>
    
  </div>
</div>


</div>
<div class="col-md-3">

<div class="media">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVkCapwPtflcAddvNeLUVwUM4oax7vxWnFBw&usqp=CAU" class="align-self-start mr-3" alt="...">
  <div class="media-body">
    <h5 class="mt-0">Comapny Name</h5>
    
  </div>
</div>


</div>
<div class="col">

<div class="media">
  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVkCapwPtflcAddvNeLUVwUM4oax7vxWnFBw&usqp=CAU" class="align-self-start mr-3" alt="...">
  <div class="media-body">
    <h5 class="mt-0">Comapny Name</h5>
    
  </div>
</div>


</div>


</div>

</div>


</div>
<?php
}

//include(WP_CONTENT_DIR . 'plugins/Deals/deals.php');
add_shortcode( 'all_deals', 'allDealsPluginShortcode');





	?>